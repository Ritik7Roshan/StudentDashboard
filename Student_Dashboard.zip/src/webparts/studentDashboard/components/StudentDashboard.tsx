import * as React from "react";
// import styles from './StudentDashboard.module.scss';
import { IStudentDashboardProps } from "./IStudentDashboardProps";
import Student_Dashboard from "./Student_Dashboard";
// import { escape } from '@microsoft/sp-lodash-subset';

export default class StudentDashboard extends React.Component<IStudentDashboardProps> {
  public render(): React.ReactElement<IStudentDashboardProps> {
    return (
      <>
        <Student_Dashboard props={this.props} />
      </>
    );
  }
}
