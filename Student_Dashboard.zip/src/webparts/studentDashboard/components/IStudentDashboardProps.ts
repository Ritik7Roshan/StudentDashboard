export interface IStudentDashboardProps {
  description: string;
  isDarkTheme: boolean;
  environmentMessage: string;
  hasTeamsContext: boolean;
  userDisplayName: string;
  context:any;
  StudentListId:any;
  FeeCollectionListId:any;
  StudentReferralListId:any;
  FeeStructureListId:any;
  StaffMemberListId:any;
}
