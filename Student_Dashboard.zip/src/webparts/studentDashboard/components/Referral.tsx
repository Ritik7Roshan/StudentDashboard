import * as React from "react";
import { Web } from "sp-pnp-js";
import "./StudentProfile.css";
import { Panel, PanelType } from "@fluentui/react/lib/Panel";
import {
  DefaultButton,
  PrimaryButton,
  TextField,
  Dropdown,
  IDropdownOption,
} from "@fluentui/react";
import Swal from "sweetalert2";

interface Student {
  FullName: string;
  Id: number;
  Email: string;
  Stream: string;
  PhoneNo: number;
  Batch?: string;
  Subjects?: string[] | string;
  ProgressReport: string;
}

interface ReferralProps {
  candidate: Student;
  props: any;
}

const Referral: React.FC<ReferralProps> = ({ candidate, props }) => {
  const [isPanelOpen, setIsPanelOpen] = React.useState(false);
  const [storeData, setStoreData] = React.useState([]);
  const [sortedData, setSortedData] = React.useState([]);
  const [courses,setCourses] = React.useState([]);
  // const [call,setCall] = React.useState(new Date().toISOString().slice(0, 16))
  const [formData, setFormData] = React.useState({
    Name: "",
    PhoneNumber: "",
    Email: "",
    Course: "",
    SchoolName: "",
    Address: "",
    Status: "",
    Created: "",
    CallSchedule: new Date().toISOString().slice(0, 16),
    Response: "",
  });

  const openPanel = () => {
    setFormData({
      Name: "",
      PhoneNumber: "",
      Email: "",
      Course: "",
      SchoolName: "",
      Address: "",
      Status: "",
      Created: "",
      CallSchedule: new Date().toISOString().slice(0, 16),
      Response: "",
    });
    setIsPanelOpen(true);
  };
  const closePanel = () => setIsPanelOpen(false);
  const testurl = props?.props?.context?.pageContext?.web?.absoluteUrl;
  const testId = props?.props?.StudentReferralListId;
  const testIdFeeStructure = props?.props?.FeeStructureListId;

  const fetchFeeStructure = async () => {
    const web = new Web(testurl);
    try {
      const res = await web.lists
        .getById(testIdFeeStructure)
        .items.select("Title","SortOrder").orderBy("SortOrder", true) 
        .get(); // Here the internal name of the Course column is "Title"
      setCourses(res);
      console.log("Fetched Fee Structure Data", res);
    } catch (error) {
      console.error("Error fetching fee structure data:", error);
    }
  }
 

  const fetchAPIData = async () => {
    const web = new Web(testurl);
    try {
      const res = await web.lists
        .getById(testId)
        .items.select(
          "Title",
          "PhoneNumber",
          "Email",
          "Course",
          "Address",
          "Created",
          "CallSchedule",
          "SchoolName",
          "StudentId"
        )
        .filter(`StudentId eq ${candidate.Id}`)
        .get();
      setStoreData(res);
      console.log("Fetched Data", res);
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  React.useEffect(() => {
    fetchAPIData();
    fetchFeeStructure();
  }, []);

  React.useEffect(() => {
    const sortData = storeData.sort(
      (a: any, b: any) =>
        new Date(b.Created).getTime() - new Date(a.Created).getTime()
    );
    setSortedData(sortData);
  }, [storeData]);

  const handleInputChange = (
    event:
      | React.FormEvent<HTMLInputElement | HTMLTextAreaElement>
      | {
          target: { name: string; value: string };
        },
    newValue?: string
  ) => {
    const { name, value } =
      "currentTarget" in event
        ? { name: event.currentTarget.name, value: newValue || "" }
        : event.target;

    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleAddReferral = async () => {
    const web = new Web(testurl);
    try {
      await web.lists.getById(testId).items.add({
        Title: formData?.Name,
        PhoneNumber: formData?.PhoneNumber,
        Email: formData?.Email,
        Course: formData?.Course,
        Address: formData?.Address,
        SchoolName: formData?.SchoolName,
        CallSchedule: formData?.CallSchedule,
        StudentId: candidate.Id,
      });

      console.log("New referral added successfully!");
      closePanel();

      await Swal.fire({
        title: "Referral Saved",
        text: "Details Enterd Saved! ",
        icon: "success",
        confirmButtonText: "OK",
      });

      fetchAPIData();
    } catch (error) {
      console.error("Error adding new referral:", error);
    }
  };

  // const courseOptions: IDropdownOption[] = [
  //   { key: "VI", text: "VI" },
  //   { key: "VII", text: "VII" },
  //   { key: "VIII", text: "VIII" },
  //   { key: "IX", text: "IX" },
  //   { key: "X", text: "X" },
  //   { key: "XI", text: "XI" },
  //   { key: "XII", text: "XII" },
  //   { key: "XI+JEE", text: "XI+JEE" },
  //   { key: "XI+NEET", text: "XI+NEET" },
  //   { key: "XII+JEE", text: "XII+JEE" },
  //   { key: "XII+NEET", text: "XII+NEET" },
  //   { key: "NEET", text: "NEET" },
  //   { key: "JEE", text: "JEE" },
  // ];

const courseOptions: IDropdownOption[] = courses.map((course: any) => ({
  key: course.Title,
  text: course.Title,
}));


  return (
    <div>
      <span className="text-right mb-3 clearfix">
        <button className="btn button-color pull-right" onClick={openPanel}>
          Add New Referrals
        </button>
      </span>
      {sortedData.length > 0 ? (
        <div className="table-responsive table-bordered">
          <table className="details-table">
            <thead className="thead-dark">
              <tr>
                <th>Name</th>
                <th>Phone Number</th>
                <th>Email</th>
                <th>Created Date</th>
                <th>Course</th>
                <th>School Name</th>
              </tr>
            </thead>
            <tbody>
              {sortedData?.map((item: any, index: number) => (
                <tr key={index}>
                  <td>{item?.Title}</td>
                  <td>{item?.PhoneNumber}</td>
                  <td>{item?.Email}</td>
                  <td>
                    {item?.Created
                      ? new Date(item.Created).toLocaleDateString("en-GB")
                      : ""}
                  </td>
                  <td>{item?.Course}</td>
                  <td>{item?.SchoolName}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <div className="no-table">
          <p className="notable-msg">No Data Available</p>
        </div>
      )}
      <Panel
        isOpen={isPanelOpen}
        onDismiss={closePanel}
        headerText="Add New Referrals"
        closeButtonAriaLabel="Close"
        isFooterAtBottom={true}
        type={PanelType.medium}
        onRenderFooterContent={() => (
          <div>
            <PrimaryButton
              onClick={handleAddReferral}
              styles={{ root: { marginRight: 8 } }}
              className="button-color"
            >
              Add Referral
            </PrimaryButton>
            <DefaultButton onClick={closePanel}>Cancel</DefaultButton>
          </div>
        )}
      >
        <div className="container">
          <div className="row">
            <div className="col-6">
              <TextField
                label="Name"
                name="Name"
                placeholder="Enter Name"
                value={formData?.Name}
                onChange={handleInputChange}
                required
                errorMessage={!formData?.Name ? "Name is required" : ""}
              />
            </div>
            <div className="col-6">
              <TextField
                label="Phone Number"
                name="PhoneNumber"
                placeholder="Enter Phone Number"
                value={formData?.PhoneNumber}
                onChange={handleInputChange}
                required
                errorMessage={
                  !formData?.PhoneNumber
                    ? "Phone Number is required"
                    : formData?.PhoneNumber.length < 10
                    ? "Phone Number must be at least 10 digits"
                    : ""
                }
              />
            </div>
          </div>
          <div className="row">
            <div className="col-6">
              <TextField
                label="Email"
                name="Email"
                placeholder="Enter Email"
                value={formData?.Email}
                onChange={handleInputChange}
                type="email"
              />
            </div>
            <div className="col-6">
              <TextField
                label="School"
                name="SchoolName"
                placeholder="Enter School Name"
                value={formData?.SchoolName}
                onChange={handleInputChange}
              />
            </div>
          </div>
          <div className="row">
            <div className="col-6">
              <Dropdown
                placeholder="Select a Course"
                options={courseOptions}
                selectedKey={formData?.Course} // Bind selected value to state
                onChange={(event, option) =>
                  handleInputChange({
                    target: { name: "Course", value: option?.key as string },
                  } as React.ChangeEvent<HTMLInputElement>)
                }
                label="Select a Course"
              />
            </div>
            <div className="col-6">
              <TextField
                label="Call Appointment"
                name="CallSchedule"
                type="datetime-local"
                placeholder="Enter Call Schedule"
                value={formData?.CallSchedule}
                onChange={handleInputChange}
              />
            </div>
          </div>
          <div className="row">
            <div className="col-12">
              <TextField
                label="Address"
                name="Address"
                placeholder="Enter Adress"
                value={formData?.Address}
                onChange={handleInputChange}
                multiline
                rows={4}
              />
            </div>
          </div>
        </div>
      </Panel>
    </div>
  );
};

export default Referral;
