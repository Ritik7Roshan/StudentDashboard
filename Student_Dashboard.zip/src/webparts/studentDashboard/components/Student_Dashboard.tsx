import * as React from "react";
import { Web } from "sp-pnp-js";
import "./StudentProfile.css";
import ProgressReport from "./ProgressReport";
import FeeDetails from "./FeeDetails";
import StudentMaterials from "./StudentMaterials";
import Referral from "./Referral";
// used CSS Imports
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/js/dist/modal.js";
import "bootstrap/js/dist/tab.js";
import "bootstrap/js/dist/carousel.js";

// import Swal from "sweetalert2";
// import { FaChevronUp, FaChevronDown } from "react-icons/fa";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";

interface Student {
  FullName: string;
  Id: number;
  Email: string;
  Course: string;
  PhoneNo: number;
  Batch?: string;
  SubjectsOpted?: string[] | string;
  ProgressReport: string;
  StudentMaterials: string;
  Photo: string;
}

const Student_Dashboard = (props: any) => {
  let currentUserId: any;
  const testUrl = props?.props?.context?.pageContext?.web?.absoluteUrl;
  const testId = props?.props?.StudentListId;
  const testIdStaff = props?.props?.StaffMemberListId;
  // let uid: any;
  const [selectedStudent, setSelectedStudent]: any =
    React.useState<Student | null>(null);
  // const [showEducationDetails, setShowEducationDetails] = React.useState(true);
  // const [showProgressReport, setShowProgressReport] = React.useState(true);
  const [showFeeDetails, setShowFeeDetails] = React.useState(false);
  // const [showSubjectsDropdown, setShowSubjectsDropdown] = React.useState(false);
  const [showStudentMaterials, setShowStudentMaterials] = React.useState(false);
  const [showReferral, setShowReferral] = React.useState(false);
  const [data, setData]: any = React.useState([]);
  const [flag, setFlag] = React.useState(false);
  const [adminId, setAdminId] = React.useState(null);
  const [selectedSubject, setSelectedSubject] = React.useState<string | null>(null);
  const [subjectTestCounts, setSubjectTestCounts] = React.useState<{ [key: string]: number }>({});


  //Applying Color hover
  const [activeTile, setActiveTile] = React.useState<string | null>(null);

  const handleTileClick = (tileName: string) => {
    setActiveTile((prevTile) => (prevTile === tileName ? null : tileName));
  };

  const getTileClass = (tileName: string) => {
    return activeTile === tileName ? "list-item1 active-tile" : "list-item1";
  };

  // const [subjects, setSubjects] = React.useState<string[]>([]);

  const [selectedSubjects, setSelectedSubjects] = React.useState<string[]>([]);

  // const handleSaveSubjects = async () => {
  //   if (!selectedStudent) return;

  //   try {
  //     const web = new Web(testUrl);
  //     await web.lists
  //       .getById(testId)
  //       .items.getById(selectedStudent.Id)
  //       .update({
  //         Subjects: selectedSubjects.join(";"), // Saving as a semicolon-separated string
  //       });

  //     setShowSubjectsDropdown(false);
  //   } catch (error) {
  //     console.error("Error updating subjects:", error);
  //     alert("Failed to update subjects.");
  //   }
  //   await Swal.fire({
  //     title: "Subject Saved",
  //     text: "Subjects Saved! ",
  //     icon: "success",
  //     confirmButtonText: "OK",
  //   });
  // };

  // removing errors
  console.log(selectedSubjects);

  // converted the subjectOpted to array
  const subjectsArray = selectedStudent?.SubjectsOpted?.map(
    (item: any) => item?.Title
  ) || [];

  // Before rendering, calculate how many tests each subject has:

  React.useEffect(() => {
    if (!selectedStudent?.ProgressReport) return;

    const parsed: ProgressReport[] = JSON.parse(selectedStudent.ProgressReport);
    const counts: { [key: string]: number } = {};

    parsed.forEach((report) => {
      report.SubjectEntries.forEach((entry) => {
        counts[entry.subject] = (counts[entry.subject] || 0) + 1;
      });
    });

    setSubjectTestCounts(counts);
  }, [selectedStudent]);

// used to set the default subject when the component mounts
  React.useEffect(() => {
    if (subjectsArray.length > 0 && !selectedSubject) {
      setSelectedSubject(subjectsArray[0]);
    }
  }, [subjectsArray, selectedSubject]);
  


  const handleSelectStudent = (student: any) => {
    setSelectedStudent(student);
    if (student?.SubjectsOpted?.Title) {
      const subjectsArray = Array.isArray(student?.SubjectsOpted?.Title)
        ? student?.SubjectsOpted?.Title
        : student?.SubjectsOpted?.Title.split(";");
      setSelectedSubjects(subjectsArray);
    } else {
      setSelectedSubjects([]);
    }
  };

  const fetchStudentById = async (id: any) => {
    const web = new Web(testUrl);
    try {
      const student = await web.lists
        .getById(testId)
        .items.getById(id)
        .select(
          "*",
          "SubjectsOpted/Id",
          "SubjectsOpted/Title",
          "Course/Title",
          "Course/Id"
        )
        .expand("SubjectsOpted", "Course")
        .get();
      console.log(student);
      if (student) {
        handleSelectStudent(student);
      } else {
        console.error(`Student with ID ${id} not found`);
        alert(`Student with ID ${id} not found`);
      }
    } catch (error) {
      console.error("Error fetching student by ID:", error);
    }
  };

  const fetchStaffById = async (Item: any) => {
    // if (!Item?.SPID?.ID) {
    //   console.error("Invalid staff ID provided to fetchStaffById.");
    //   return;
    // }
    // const web = new Web("https://smalsusinfolabs.sharepoint.com/sites/IITIQ");
    // try {
    //   const staff = await web.lists.getByTitle("StaffMembers").items.get();
    //   console.log(staff);

    //   const matched = staff.filter((ele: any) => {
    //     return ele?.SPIDId === Item?.SPID?.ID;
    //   });
    //   if (matched) {
    //     handleSelectStudent(matched[0]);
    //   } else {
    //     console.error(`Staff with ID ${Item.SPIDId} not found`);
    //   }
    // } catch (error) {
    //   console.error("Error fetching staff by ID:", error);
    // }
    handleSelectStudent(Item);
  };

  const subjectReports = React.useMemo(() => {
    if (!selectedSubject || !selectedStudent?.ProgressReport) return [];

    const parsed: ProgressReport[] = JSON.parse(selectedStudent.ProgressReport);
    const filtered = parsed.flatMap(report =>
      report.SubjectEntries.filter(entry => entry.subject === selectedSubject)
        .map(entry => ({
          date: entry.date,
          subject: entry.subject,
          obtained: entry.obtained,
          full: entry.full,
          percentage: (entry.obtained / entry.full) * 100
        }))
    );

    return filtered.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  }, [selectedSubject, selectedStudent]);


  // const fetchSubjects = async () => {
  //   const web = new Web(testUrl);
  //   try {
  //     const field = await web.lists
  //       .getById(testId)
  //       .fields.getByTitle("Subjects")
  //       .get();
  //     if (
  //       field.TypeAsString === "Choice" ||
  //       field.TypeAsString === "MultiChoice"
  //     ) {
  //       setSubjects(field.Choices || []);
  //     } else {
  //       console.error("Field is not a choice or multi-choice field");
  //     }
  //   } catch (error) {
  //     console.error("Error fetching subjects:", error);
  //   }
  // };

  const fetchAPIData = async () => {
    const urlParams = new URLSearchParams(window.location.search);
    const studentId = urlParams.get("StudentId");
    const staffId = urlParams.get("StaffId");

    console.log("Query Param: ", studentId);

    if (studentId || staffId) {
      if (studentId) {
        currentUserId = studentId;
      } else currentUserId = staffId;
    } else {
      currentUserId =
        props?.props?.context?._pageContext?._legacyPageContext?.userId ||
        "Invalid Id";
    }

    // const currentUserName =
    //   props.props._pageContext._legacyPageContext.userDisplayName ||
    //   "Guest User";
    const web = new Web(testUrl);
    try {
      const Students = await web.lists
        .getById(testId)
        .items.select("ID", "SPID/ID", "SPID/Title")
        .expand("SPID")
        .get();
      console.log("Fetched data:", Students);

      const Staff = await web.lists.getById(testIdStaff).items.get();
      const combinedData = [...Students, ...Staff];
      setData(combinedData);
      let Item: any;

      // SPID Matching condition

      // const Item = combinedData.find(
      //   (item: any) => currentUserId == (item?.SPID?.ID || item?.SPIDId)
      // );

      // Item Id matching condition
      if (studentId === null && staffId === null) {
        Item = combinedData.find(
          (item: any) => currentUserId == (item?.SPID?.ID || item?.SPIDId)
        );
      } else {
        Item = combinedData.find((item: any) => currentUserId == item?.ID);
      }

      if (Item) {
        if (Item?.Types == undefined) {
          setFlag(true);
          fetchStudentById(Number(Item.ID));
        } else {
          // fetchStaffById(Number(Item.SPID.ID));
          fetchStaffById(Item);
        }
      }
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };
  // React.useEffect(() => {
  //   const urlParams = new URLSearchParams(window.location.search);
  //   const studentId = urlParams.get("StudentId");

  //   const currentUserId =
  //     props.props._pageContext._legacyPageContext.userId || "Invalid Id";
  //   const currentUserName =
  //     props.props._pageContext._legacyPageContext.userDisplayName ||
  //     "Guest User";

  //   data?.forEach((item: any) => {
  //     if (currentUserName === "Deepak Trivedi") {
  //       fetchStudentById(studentId);
  //     } else if (currentUserId == item?.SPID?.ID && item?.Types === null) {
  //       fetchStudentById(Number(item.ID));
  //     } else if (currentUserId == item?.SPID?.ID && item?.Types !== null) {
  //       fetchStaffById(Number(item?.SPID?.ID));
  //     }
  //   });
  // }, [data]);

  React.useEffect(() => {
    fetchAPIData();
    // fetchSubjects();
  }, []);

  console.log("Complete Data : ", data);

  // const fetchStaffById = async (id: any) => {
  //   const web = new Web("https://smalsusinfolabs.sharepoint.com/sites/IITIQ");
  //   try {
  //     const student = await web.lists
  //       .getByTitle("StaffMembers")
  //       .items.getById(id)
  //       .get();
  //     console.log(student);
  //     if (student) {
  //       handleSelectStudent(student);
  //     } else {
  //       console.error(`Student with ID ${id} not found`);
  //       alert(`Student with ID ${id} not found`);
  //     }
  //   } catch (error) {
  //     console.error("Error fetching student by ID:", error);
  //   }
  // };

  // React.useEffect(() => {
  //   const urlParams = new URLSearchParams(window.location.search);
  //   const studentId = urlParams.get("StudentId");

  //   const currentUserId =
  //     props.props._pageContext._legacyPageContext.userId || "Invalid Id";
  //   const currentUserName =
  //     props.props._pageContext._legacyPageContext.userDisplayName ||
  //     "Guest User";

  //   if (currentUserName === "Deepak Trivedi") {
  //     fetchStudentById(studentId);
  //   } else {
  //     const Item = data.find((item: any) => currentUserId == item?.SPID?.ID);

  //     if (Item) {
  //       if (Item?.Types === null) {
  //         fetchStudentById(Number(Item.ID));
  //       } else {
  //         fetchStaffById(Number(Item.SPID.ID));
  //       }
  //     }
  //   }
  // }, [data]);

  // const toggleEducationDetails = () => {
  //   setShowEducationDetails((prev) => !prev);
  // };

  // const toggleProgressReport = () => {
  //   setShowProgressReport((prev) => !prev);
  //   setShowFeeDetails(false);
  //   setShowStudentMaterials(false);
  //   setShowReferral(false);
  // };

  const toggleFeeDetails = () => {
    setShowFeeDetails((prev) => !prev);
    // setShowProgressReport(false);
    setShowStudentMaterials(false);
    setShowReferral(false);
  };

  const toggleStudentMaterials = () => {
    setShowStudentMaterials((prev) => !prev);
    setShowReferral(false);
    // setShowProgressReport(false);
    setShowFeeDetails(false);
  };

  const toggleReferral = () => {
    setShowReferral((prev) => !prev);
    // setShowProgressReport(false);
    setShowFeeDetails(false);
    setShowStudentMaterials(false);
  };

  // const adminPermission = async () => {
  //   const web = new Web(testUrl);
  //   const logedInUser = await web.currentUser.get();
  //   const userGroups: any = await web.siteUsers
  //     .getById(logedInUser.Id)
  //     .groups.get();
  //   const uid = userGroups?.some((group: any) =>
  //     group?.Title?.includes("IITIQ Admins")
  //   );
  //   if (uid) {
  //     setAdminId(logedInUser.Id);
  //   }
  // };

  const adminPermission = async () => {
  const web = new Web(testUrl);
  const logedInUser = await web.currentUser.get();
  const userGroups: any = await web.siteUsers
    .getById(logedInUser.Id)
    .groups.get();

  // List of allowed admin groups
  const allowedAdminGroups = ["IITIQ Admins", "TSO Admins"];

  // Check if user is in any of the allowed groups
  const isAdmin = userGroups?.some((group: any) =>
    allowedAdminGroups.some(adminGroup =>
      group?.Title?.toLowerCase().includes(adminGroup.toLowerCase())
    )
  );

  if (isAdmin) {
    setAdminId(logedInUser.Id);
  }
};

  React.useEffect(() => {
    adminPermission();
  }, []);

  const getLogoUrl = () => 
    {
       const currentUrl = window.location.href.toLowerCase();
       if(currentUrl.includes("/tso/")){
        return "https://smalsusinfolabs.sharepoint.com/sites/TSO/Pictures/Logo/TSO_Logo.jpg";
    }
    else if(currentUrl.includes("/iitiq/")){
      return "https://smalsusinfolabs.sharepoint.com/sites/IITIQ/Pictures/StudentImage/iitq.png";
    }
    return ""
  }
  const logoUrl = getLogoUrl();

  // const handleFileDrop = async (event: React.DragEvent<HTMLDivElement>) => {
  //   event.preventDefault();

  //   if (!selectedStudent) {
  //     alert("No student selected to associate the photo with.");
  //     return;
  //   }

  //   const files = event.dataTransfer.files;
  //   if (files.length === 0) {
  //     alert("No file dropped.");
  //     return;
  //   }

  //   const file = files[0];
  //   if (!file.type.startsWith("image/")) {
  //     alert("Please drop an image file.");
  //     return;
  //   }

  //   const folderName = "StudentPhotos";
  //   const libraryName = "Students_Picture";
  //   const web = new Web("https://smalsusinfolabs.sharepoint.com/sites/IITIQ");

  //   try {
  //     const fileContent = await file.arrayBuffer();
  //     const fileName = `${selectedStudent.Id}_${file.name}`;

  //     // Upload the file to SharePoint
  //     const uploadResult = await web
  //       .getFolderByServerRelativeUrl(
  //         `/sites/IITIQ/${libraryName}/${folderName}`
  //       )
  //       .files.add(fileName, fileContent, true);

  //     // Get the file URL
  //     let fileUrl = uploadResult.data.ServerRelativeUrl;
  //     fileUrl = "https://smalsusinfolabs.sharepoint.com" + fileUrl;
  //     const hyperlinkValue = {
  //       Url: fileUrl,
  //       Description: file.name,
  //     };

  //     await web.lists
  //       .getByTitle("Students")
  //       .items.getById(selectedStudent.Id)
  //       .update({
  //         Photo: hyperlinkValue,
  //       });

  //     console.log(fileUrl);

  //     // Update the local state to display the new photo
  //     setSelectedStudent((prev: any) => ({
  //       ...prev,
  //       Photo: hyperlinkValue,
  //     }));

  //     alert("Photo uploaded successfully!");
  //   } catch (error) {
  //     console.error("Error uploading file:", error);
  //     alert("Failed to upload the file.");
  //   }
  // };

  const subjectss = selectedStudent?.SubjectsOpted?.map(
    (item: any) => item?.Title
  )?.join(",");



  // const colors = ["#8884d8", "#82ca9d", "#ff7300", "#ff0000"]; // Add more if needed
  // const subjectColors = subjectss
  //   ?.split(",")
  //   .reduce((acc: Record<string, string>, subject: string, index: number) => {
  //     acc[subject] = colors[index % colors.length]; // Assign colors cyclically
  //     return acc;
  //   }, {});

  const defaultChartData = Array.from({ length: 12 }, (_, index) => {
    const month = new Date(2025, index, 1).toLocaleString("en-US", {
      month: "short",
      year: "numeric",
    });
    console.log(defaultChartData);
    return {
      Date: month,
      Total: 0,
    };
  });

  // Preparing content for the Tooltip
  const CustomTooltip = ({active,payload,label}:any)=>{
    if(active && payload && payload.length){
      const data= payload[0].payload;
      const rawDate= new Date (data.date);
      const day = String(rawDate.getDate()).padStart(2,'0');
      const month= String(rawDate.getMonth()+1).padStart(2,'0');
      const year= String(rawDate.getFullYear()).padStart(2,'0');
      return (
        <div className="bg-white p-3 rounded shadow text-sm">
          <p><strong>Date: </strong>{`${day}-${month}-${year}`}</p>
          <p><strong>Marks Obtained: </strong>{data.obtained}</p>
          <p><strong>Full Marks: </strong>{data.full}</p>
          <p><strong>Percentage: </strong>{data.percentage.toFixed(2)}%</p>
        </div>
      )
    }
     return null;
  }
  return (
    <div className="container student-dashboard">
      <header className="header">
        <h1 style={{ textAlign: "center", width: "100%" }}>My Dashboard</h1>
      </header>
      {selectedStudent ? (
        <>
          <div className="logo-header">
            <div className="profile-section">
              <div className="photo-placeholder">
                <img
                  className="photo-placeholder-img"
                  src={selectedStudent.Photo?.Url}
                  alt=""
                />
              </div>
              <div className="details-container">
                {/* <p>
                <strong>ID :</strong> {selectedStudent?.Id}
              </p> */}
                <p className="fullName">
                  <strong>Name:</strong>{" "}
                  <strong>
                    {selectedStudent?.FirstName +
                      " " +
                      selectedStudent?.LastName || " "}
                  </strong>
                </p>
                <p>
                  <strong>Email:</strong> {selectedStudent?.Email}
                </p>
                {flag && (
                  <p>
                    <strong>Stream:</strong> {selectedStudent?.Course?.Title}
                  </p>
                )}
                {flag && (
                  <p>
                    <strong>Subject:</strong> {subjectss}
                  </p>
                )}
                {flag && (
                  <p>
                    <strong>Batch:</strong> {selectedStudent?.Batch || ""}
                  </p>
                )}
                <p>
                  <strong>Mobile Number:</strong> {selectedStudent?.PhoneNo}
                </p>
              </div>
            </div>
            <div className="photo-placeholder logo">
              <img
                className="photo-placeholder-img"
                src={logoUrl}
                alt=""
              />
            </div>
          </div>

          <section className="list-section">
            <div className="list">
              <div className="tile-str row">
                <div>
                  <ul className="subjectTab">
                    {subjectsArray.map((subject: string, index:any) => (
                      <li
                        key={subject}
                        onClick={() => setSelectedSubject(subject)}
                        className={`listTab ${selectedSubject === subject
                            ? 'activeTab'
                            :''}
                          `}
                      >
                        {subject} ({subjectTestCounts[subject] ?? 0})
                      </li>
                    ))}
                  </ul>
                  <div className="tabContent">
                    <div className="row">
                  <div className="col-6">
                  <div className="list-section1 mb-3">
                    {flag && selectedSubject && (
                      <>
                        <h4 className="text-xl font-bold py-2 px-3">{selectedSubject} Progress</h4>

                        <ResponsiveContainer width="100%" height={300}>
                          <LineChart data={subjectReports}>
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="date"
                            tickFormatter={(value)=>{
                              const date = new Date(value);
                              const day = String(date.getDate()).padStart(2,'0');
                              const month = String( date.getMonth()+1).padStart(2,'0');
                              return `${day}/${month}`;
                            }}/>
                            <YAxis domain={[0, 100]} unit="%" />
                            <Tooltip content={<CustomTooltip/>} />
                            <Legend />
                            <Line type="monotone" dataKey="percentage" stroke="#8884d8" dot={{ r: 4 }} />
                          </LineChart>
                        </ResponsiveContainer>


                      </>
                    )}

                  </div>
                </div>
                <div className="col-6">
                  {flag && (
                    <>
                      <ProgressReport
                        candidate={selectedStudent}
                        props={props}
                        fetchStudentById={fetchStudentById}
                        subjectReports={subjectReports}
                      />
                    </>
                  )}
                </div></div>
                  </div>
                </div>


                
              
              </div>
              <div className="tile-str row">
                <div className="col-4">
                  <div className="list-section1">
                    {flag && (
                      <div
                        className={getTileClass("FeeDetails")}
                        onClick={() => {
                          toggleFeeDetails();
                          handleTileClick("FeeDetails");
                        }}
                      >
                        Fee Details
                      </div>
                    )}
                  </div>
                </div>
                <div className="col-4">
                  <div className="list-section1">
                    {flag && (
                      <div
                        className={getTileClass("StudentMaterials")}
                        onClick={() => {
                          toggleStudentMaterials();
                          handleTileClick("StudentMaterials");
                        }}
                      >
                        Student Material
                      </div>
                    )}
                  </div>
                </div>
                {selectedStudent.Types == null ? (
                  <div className="col-4">
                    <div className="list-section1">
                      <div
                        className={getTileClass("Referral")}
                        onClick={() => {
                          toggleReferral();
                          handleTileClick("Referral");
                        }}
                      >
                        Add a Referral
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="list-section1">
                    <div className="col-12">
                      <div
                        className={getTileClass("Referral")}
                        onClick={() => {
                          toggleReferral();
                          handleTileClick("Referral");
                        }}
                      >
                        Add a Referral
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {flag && showStudentMaterials && (
              <StudentMaterials
                candidate={selectedStudent}
                context={props.props.context}
                admin={adminId}
                props={props}
              />
            )}
            {flag && showFeeDetails && (
              <FeeDetails
                candidate={selectedStudent}
                admin={adminId}
                props={props}
              />
            )}
            {showReferral && (
              <Referral candidate={selectedStudent} props={props} />
            )}
          </section>
        </>
      ) : (
        <p style={{ textAlign: "center" }}>
          No student selected : Pass Valid ID in URL to view.
        </p>
      )}
    </div>
  );
};
export default Student_Dashboard;
