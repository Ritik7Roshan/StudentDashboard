
require("./StudentDashboard.module.css");
const styles = {
  studentDashboard: 'studentDashboard_6d2e4292',
  teams: 'teams_6d2e4292',
  welcome: 'welcome_6d2e4292',
  welcomeImage: 'welcomeImage_6d2e4292',
  links: 'links_6d2e4292'
};

export default styles;
