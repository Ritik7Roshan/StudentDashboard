import * as React from "react";
import { Web } from "sp-pnp-js";
import "./StudentProfile.css";
import { Panel, PanelType } from "@fluentui/react/lib/Panel";
import { DefaultButton, PrimaryButton, TextField } from "@fluentui/react";
// import { NormalPeoplePicker } from "@fluentui/react/lib/Pickers";
// import { IPersonaProps } from "@fluentui/react";
import { Label } from "@fluentui/react";
import {
  PeoplePicker,
  PrincipalType,
} from "@pnp/spfx-controls-react/lib/PeoplePicker";
import Swal from "sweetalert2";
import { WebPartContext } from "@microsoft/sp-webpart-base";

interface Student {
  FullName: string;
  Id: number;
  Email: string;
  Stream: string;
  PhoneNo: number;
  Batch?: string;
  Subjects?: string[] | string;
  StudentMaterials: string; // JSON string containing the student materials entries
}

interface StudentMaterial {
  Date: string;
  Books: string;
  IssuedBy: string;
}

interface StudentMaterialsProps {
  candidate: Student;
  context: WebPartContext;
  admin: any;
  props: any;
}

const StudentMaterials: React.FC<StudentMaterialsProps> = ({
  candidate,
  context,
  admin,
  props,
}) => {
  const [studentMaterials, setStudentMaterials] = React.useState<
    StudentMaterial[]
  >(candidate.StudentMaterials ? JSON.parse(candidate.StudentMaterials) : []);
  const [isPanelOpen, setIsPanelOpen] = React.useState(false);
  const [newMaterial, setNewMaterial] = React.useState<StudentMaterial>({
    Date: "",
    Books: "",
    IssuedBy: "",
  });
  const testurl = props?.props?.context?.pageContext?.web?.absoluteUrl;
  const testId = props?.props?.StudentListId;
  // const [selectedPerson, setSelectedPerson] =
  //   React.useState<IPersonaProps | null>(null);
  const handleOpenPanel = () => {
    setIsPanelOpen(true);
  };
  const handleClosePanel = () => {
    setIsPanelOpen(false);
  };

  // console.log(selectedPerson);

  const handleInputChange = (
    event: React.FormEvent<HTMLInputElement | HTMLTextAreaElement>,
    field: keyof StudentMaterial
  ) => {
    const target = event.target as HTMLInputElement; // Explicitly cast the target
    const { value } = target;
    setNewMaterial((prevMaterial) => ({
      ...prevMaterial,
      [field]: value,
    }));
  };

  // const fetchSuggestions = async (
  //   filterText: string
  // ): Promise<IPersonaProps[]> => {
  //   if (!filterText) return [];
  //   try {
  //     const web = new Web(testurl);
  //     const results = await web.siteUsers
  //       .filter(`substringof('${filterText}',Title)`)
  //       .get();
  //     return results.map((user: any) => ({
  //       text: user.Title,
  //       secondaryText: user.Email,
  //       id: user.Id.toString(),
  //     }));
  //   } catch (error) {
  //     console.error("Error fetching user suggestions:", error);
  //     return [];
  //   }
  // };

  // const handlePeoplePickerChange = (items: IPersonaProps[]) => {
  //   if (items.length > 0) {
  //     setNewMaterial((prev: any) => ({
  //       ...prev,
  //       IssuedBy: items[0].text, // Store the selected person's name
  //     }));
  //     setSelectedPerson(items[0]); // Save selected person details
  //   } else {
  //     setNewMaterial((prev) => ({ ...prev, IssuedBy: "" }));
  //     setSelectedPerson(null);
  //   }
  // };

  const handlePeoplePickerChange = (items: any[]) => {
    if (items.length > 0) {
      setNewMaterial((prev) => ({
        ...prev,
        IssuedBy: items[0].text, // Set the selected person's name
      }));
    } else {
      setNewMaterial((prev) => ({
        ...prev,
        IssuedBy: "",
      }));
    }
  };

  const addMaterial = async () => {
    const updatedMaterials = [...studentMaterials, newMaterial];
    setStudentMaterials(updatedMaterials);

    try {
      const web = new Web(testurl);
      await web.lists
        .getById(testId)
        .items.getById(candidate.Id)
        .update({
          StudentMaterials: JSON.stringify(updatedMaterials),
        });
      console.log("Student materials updated successfully.");
    } catch (error) {
      console.error("Error updating student materials:", error);
    }
    setIsPanelOpen(false);
    setNewMaterial({
      Date: "",
      Books: "",
      IssuedBy: "",
    });
    await Swal.fire({
      title: "Books added",
      text: "Books added Successfully!",
      icon: "success",
      confirmButtonText: "OK",
    });
  };

  const peoplePickerContext = {
    ...context,
    absoluteUrl: context?.pageContext?.web.absoluteUrl,
    msGraphClientFactory: context?.msGraphClientFactory,
    spHttpClient: context?.spHttpClient,
  };

  console.log(admin);
  return (
    <div>
      <div className="text-right mb-3 clearfix">
        {admin && (
          <button
            className="btn button-color pull-right"
            onClick={handleOpenPanel}
          >
            Add New Material
          </button>
        )}
      </div>

      {studentMaterials.length > 0 ? (
        <div className="table-responsive table-bordered">
          {/* <h3>Materials for {candidate.FullName}</h3> */}
          <table className="details-table">
            <thead className="thead-dark">
              <tr>
                <th>Date</th>
                <th>Name</th>
                <th>Books Issued</th>
                <th>Issued By</th>
              </tr>
            </thead>
            <tbody>
              {studentMaterials.map((material, index) => (
                <tr key={index}>
                  <td>{new Date(material.Date).toLocaleDateString("en-GB")}</td>
                  <td>{candidate.FullName}</td>
                  <td>{material.Books}</td>
                  <td>{material.IssuedBy}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <div className="no-table">
          <p className="notable-msg">No Data Available</p>
        </div>
      )}
      <Panel
        isOpen={isPanelOpen}
        onDismiss={handleClosePanel}
        headerText="Add New Material"
        type={PanelType.medium}
        isFooterAtBottom={true}
        onRenderFooterContent={() => (
          <div>
            <PrimaryButton
              onClick={addMaterial}
              styles={{ root: { marginRight: 8 } }}
              className="button-color"
            >
              Add Entry
            </PrimaryButton>
            <DefaultButton onClick={handleClosePanel}>Cancel</DefaultButton>
          </div>
        )}
      >
        <div className="container">
          <div className="row">
            <div className="col-6">
              <TextField
                label="Date"
                type="date"
                value={newMaterial.Date}
                onChange={(e) => handleInputChange(e, "Date")}
              />
            </div>
            <div className="col-6">
              <TextField label="Name" value={candidate.FullName} readOnly />
            </div>
          </div>
          <div className="row">
            <div className="col-6">
              <TextField
                label="Books Issued"
                value={newMaterial.Books}
                onChange={(e) => handleInputChange(e, "Books")}
              />
            </div>
            <div className="col-6">
              {/* <Label htmlFor="peoplePicker">Issued By</Label> */}
              {/* <NormalPeoplePicker
                onResolveSuggestions={fetchSuggestions}
                onChange={handlePeoplePickerChange}
                pickerSuggestionsProps={{
                  suggestionsHeaderText: "Suggested People",
                  noResultsFoundText: "No results found",
                }}
                inputProps={{ placeholder: "Enter name..." }}
              /> */}

              <Label htmlFor="peoplePicker">Issued By</Label>
              <PeoplePicker
                context={peoplePickerContext}
                placeholder="Enter name..."
                personSelectionLimit={1}
                showHiddenInUI={false}
                principalTypes={[PrincipalType.User]}
                resolveDelay={200}
                onChange={handlePeoplePickerChange}
              />
            </div>
          </div>
        </div>
      </Panel>
    </div>
  );
};

export default StudentMaterials;
