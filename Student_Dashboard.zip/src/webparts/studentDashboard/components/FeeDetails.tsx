import * as React from "react";
import { Web } from "sp-pnp-js";
import { Panel, PanelType } from "@fluentui/react";
import {
  PrimaryButton,
  DefaultButton,
  TextField,
  Dropdown,
  // ChoiceGroup,
  IDropdownOption,
} from "@fluentui/react";
import "./StudentProfile.css";
import Swal from "sweetalert2";

interface Student {
  FullName: string;
  Id: number;
}

interface Fee {
  Id: number;
  dueDate?: any;
  DueAmount: number;
  ReceivedAmount: number;
  ReceivedDate: any;
  PaymentMode: string;
  Student: Student;
  Status: string;
}

type FeeDetailsProps = {
  candidate: Student;
  admin: any;
  props: any;
};

const FeeDetails: React.FC<FeeDetailsProps> = ({ candidate, props, admin }) => {
  const [storeData, setStoreData] = React.useState<Fee[]>([]);
  const [storeStudentData, setStoreStudentData] = React.useState<any>(null);
  const [filteredData, setFilteredData] = React.useState<any[]>([]);
  const [isPanelOpen, setIsPanelOpen] = React.useState(false);
  const [newEntry, setNewEntry] = React.useState<Fee>({
    Id: 0,
    dueDate: "",
    DueAmount: 0,
    ReceivedAmount: 0,
    ReceivedDate: "",
    PaymentMode: "",
    Student: candidate,
    Status: "unpaid",
  });
  const [editMode, setEditMode] = React.useState(false);
  // let uid: number;

  const paymentOptions: IDropdownOption[] = [
    { key: "Net Banking", text: "Net Banking" },
    { key: "Cash", text: "Cash" },
    { key: "Cheque", text: "Cheque" },
    { key: "UPI", text: "UPI" },
  ];

  // const statusOptions: IDropdownOption[] = [
  //   { key: "Paid", text: "Paid" },
  //   { key: "Unpaid", text: "Unpaid" },
  //   { key: "Partial Paid", text: "Partial Paid" },
  // ];

  console.log(filteredData);

  const testurl = props?.props?.context?.pageContext?.web?.absoluteUrl;
  const testId = props?.props?.FeeCollectionListId;
  const testIdStudents = props?.props?.StudentListId;
  const testIdFeeStructure = props?.props?.FeeStructureListId;
   
  const fetchAPIData = async () => {
    const web = new Web(testurl);
    try {
      const res = await web.lists
        .getById(testId)
        .items.select(
          "Id,dueDate,ReceivedDate,ReceivedAmount,DueAmount,TotalAmount,PaymentMode,Status,Student/FullName,Student/Id"
        )
        .expand("Student")
        .get();
      setStoreData(res);
      console.log("Fetched Data", res);
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  const dataFiltered = storeData.filter((item) => {
    return item.Student.Id === candidate.Id;
  }).sort((a, b) => (new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime()));

  // Fetching details of candidate from Student list
  const fetchAPIStudent = async () => {
    const web = new Web(testurl);
    try {
      const res = await web.lists
        .getById(testIdStudents)
        .items.getById(candidate.Id)
        .get();
      setStoreStudentData(res);
      console.log(`Student List data for ${candidate.FullName} is : `, res);
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };
  console.log(storeStudentData);

  // Calculate Due Date
  const calculateDueDates = (
    admissionDate: string,
    schedule: string
  ): string[] => {
    const dates: string[] = [];
    const startDate = new Date(admissionDate);

    switch (schedule.toLowerCase()) {
      case "monthlyfee": {
        for (let i = 1; i <= 12; i++) {
          const nextDate = new Date(
            startDate.getFullYear(),
            startDate.getMonth() + i,
            startDate.getDate()
          );
          dates.push(nextDate.toISOString().split("T")[0]);
        }
        break;
      }

      case "quarterlyfee": {
        for (let i = 1; i <= 4; i++) {
          const nextDate = new Date(
            startDate.getFullYear(),
            startDate.getMonth() + i * 3,
            startDate.getDate()
          );
          dates.push(nextDate.toISOString().split("T")[0]);
        }
        break;
      }

      case "halfyearlyfee": {
        for (let i = 1; i <= 2; i++) {
          const nextDate = new Date(
            startDate.getFullYear(),
            startDate.getMonth() + i * 6,
            startDate.getDate()
          );
          dates.push(nextDate.toISOString().split("T")[0]);
        }
        break;
      }

      case "yearly": {
        const yearlyDate = new Date(
          startDate.getFullYear() + 1,
          startDate.getMonth(),
          startDate.getDate()
        );
        dates.push(yearlyDate.toISOString().split("T")[0]);

        break;
      }

      default: {
        console.error("Unsupported FeeSchedule type:", schedule);
      }
    }

    return dates;
  };

  function toDateInputString(date: string | Date) {
    const d = date instanceof Date ? date : new Date(date);
    return d.toISOString().split("T")[0];
  }

  const calculateStatus = (received: number, due: number): string => {
    if (received === 0 && due > 0) return "Unpaid";
    if (received > 0 && received < due) return "Partial Paid";
    if (received >= due) return "Paid";
    return "Unpaid";
  };



  // Fetching Course detail from FeeStructures
  // const fetchCourseDetailsAndCalculateDue = async () => {
  //   const web = new Web("https://smalsusinfolabs.sharepoint.com/sites/IITIQ");

  //   try {
  //     // Fetch the Course details based on the CourseId
  //     const courseId = storeStudentData?.CourseId; // Assuming the student's CourseId is available in storeStudentData
  //     const course = await web.lists
  //       .getByTitle("FeeStructures")
  //       .items.getById(courseId)
  //       .get();

  //     console.log("Fetched Course Data:", course);

  //     // Determine the applicable fee field based on the student's FeeSchedule
  //     const feeSchedule = storeStudentData?.FeeSchedule; // Assuming FeeSchedule exists in storeStudentData
  //     const feeField = course[feeSchedule];

  //     console.log("Subscription feild : ", feeField);

  //     if (feeField) {
  //       // Calculate Fee Discount
  //       const feeDiscount = storeStudentData?.FeeDiscount || 0; // Assuming FeeDiscount exists in student data
  //       const discountedAmount = feeField - (feeField * feeDiscount) / 100;

  //       // Update DueAmount for the student
  //       setNewEntry((prev) => ({
  //         ...prev,
  //         DueAmount: discountedAmount,
  //       }));

  //       console.log("Calculated Due Amount:", discountedAmount);
  //       // return discountedAmount;
  //     } else {
  //       console.warn("No matching FeeSchedule field found in Course data.");
  //       // return null;
  //     }
  //   } catch (error) {
  //     console.error(
  //       "Error fetching Course details or calculating Due Amount:",
  //       error
  //     );
  //     // return null;
  //   }
  // };

  // const updateFilteredDataWithDiscount = async () => {
  //   if (storeStudentData) {
  //     const { AdmissionDate, FeeSchedule, FeeDiscount = 0 } = storeStudentData;
  //     if (AdmissionDate && FeeSchedule) {
  //       // Calculate due dates
  //       const dueDates = calculateDueDates(AdmissionDate, FeeSchedule);

  //       try {
  //         const web = new Web(
  //           "https://smalsusinfolabs.sharepoint.com/sites/IITIQ"
  //         );
  //         const courseId = storeStudentData?.CourseId;
  //         const course = await web.lists
  //           .getByTitle("FeeStructures")
  //           .items.getById(courseId)
  //           .get();

  //         const feeField = course[FeeSchedule];
  //         if (feeField) {
  //           const discountedAmount = feeField - (feeField * FeeDiscount) / 100;

  //           const updatedData = dueDates.map((dueDate, index) => ({
  //             Id: index + 1,
  //             dueDate: dueDate,
  //             DueAmount: discountedAmount,
  //             ReceivedDate: "",
  //             ReceivedAmount: 0,
  //             PaymentMode: "N/A",
  //             Student: candidate,
  //             Status: "Unpaid",
  //           }));

  //           setFilteredData(updatedData);
  //         } else {
  //           console.warn("No matching FeeSchedule field found in Course data.");
  //         }
  //       } catch (error) {
  //         console.error("Error updating filtered data with discount:", error);
  //       }
  //     }
  //   }
  // };

  const updateFilteredDataWithDiscount = async () => {
    if (storeStudentData) {
      const { AdmissionDate, FeeSchedule, FeeDiscount = 0 } = storeStudentData;

      if (AdmissionDate && FeeSchedule) {
        // Calculate due dates
        const admDate = new Date(AdmissionDate).toISOString().split("T")[0];
        const dueDates = calculateDueDates(admDate, FeeSchedule);

        try {
          const web = new Web(testurl);
          const courseId = storeStudentData?.CourseId;
          const course = await web.lists
            .getById(testIdFeeStructure)
            .items.getById(courseId)
            .get();

          const feeField = course[FeeSchedule];
          if (feeField) {
            const discountedAmount = feeField - (feeField * FeeDiscount) / 100;

            // Check for existing entries in the backend
            const existingEntries = storeData.filter(
              (item: Fee) => item.Student?.Id === candidate.Id
            );

            let diff = 0;

            // Prepare updated filtered data
            const updatedData = dueDates.map((dueDate, index) => {
              // Check if an entry for this due date exists
              const existingEntry = existingEntries.find(
                (item) =>
                  new Date(item.dueDate).toISOString().split("T")[0] === dueDate
              );

              // const diff=existingEntry?.DueAmount-existingEntry?.ReceivedAmount

              if (existingEntry) {
                // Calculate and accumulate diff
                diff = existingEntry.DueAmount - existingEntry.ReceivedAmount;
                // Mark as Paid if entry exists
                return {
                  ...existingEntry,
                };
              } else {
                // Otherwise, create a new unpaid entry
                const newEntry = {
                  Id: index + 1,
                  dueDate: toDateInputString(dueDate) || null,
                  DueAmount: discountedAmount,
                  ReceivedDate: null,
                  ReceivedAmount: 0,
                  PaymentMode: "N/A",
                  Student: candidate,
                  Status: "Unpaid",
                };

                // Add the diff to the first new entry after the existing entry
                if (diff !== 0) {
                  newEntry.DueAmount += diff;
                  diff = 0; // Reset diff after applying
                }
                return newEntry;
              }
            });

            setFilteredData(updatedData);
          } else {
            console.warn("No matching FeeSchedule field found in Course data.");
          }
        } catch (error) {
          console.error("Error updating filtered data with discount:", error);
        }
      }
    }
  };

  React.useEffect(() => {
    updateFilteredDataWithDiscount();
  }, [storeStudentData, candidate.Id]);

  console.log(storeData);

  // const handleInputChange = (
  //   event: React.FormEvent<HTMLInputElement | HTMLTextAreaElement>,
  //   field: keyof Fee
  // ) => {
  //   const target = event.target as HTMLInputElement;
  //   // const value =
  //   //   field === "ReceivedDate" || field === "dueDate"
  //   //     ? new Date(target.value)
  //   //     : target.value;
  //   const value = target.value;

  //   setNewEntry((prev) => ({
  //     ...prev,
  //     [field]: value,
  //   }));
  // };

  const handleInputChange = (
    event: React.FormEvent<HTMLInputElement | HTMLTextAreaElement>,
    field: keyof Fee
  ) => {
    const target = event.target as HTMLInputElement;
    const value = field === "ReceivedAmount" || field === "DueAmount"
      ? Number(target.value)
      : target.value;

    setNewEntry((prev) => {
      const updated = {
        ...prev,
        [field]: value,
      };

      // Auto-calculate and update the status in real-time
      if (field === "ReceivedAmount" || field === "DueAmount") {
        updated.Status = calculateStatus(updated.ReceivedAmount, updated.DueAmount);
      }

      return updated;
    });
  };

  const handleOpenPanel = (item: any = null) => {
    if (item) {
      // Edit Mode
      //const todayDate = new Date().toISOString().split("T")[0];

      setNewEntry({
        Id: item.Id,
        dueDate: item.dueDate ? toDateInputString(item.dueDate) : null,
        ReceivedDate: item.ReceivedDate ? toDateInputString(item.ReceivedDate) : null,
        ReceivedAmount: item.ReceivedAmount,
        DueAmount: item.DueAmount,
        PaymentMode: item.PaymentMode,
        Status: item.Status,
        Student: candidate,
      });
      setEditMode(true);
      // handleSave();
    } else {
      // Add New Mode
      //  const today = toDateInputString(new Date());
      setNewEntry({
        Id: 0,
        dueDate: null,
        ReceivedDate: null,
        ReceivedAmount: 0,
        DueAmount: 0,
        PaymentMode: "",
        Student: candidate,
        Status: "Unpaid",
      });
      setEditMode(false);
    }
    setIsPanelOpen(true);
  };

  // const handleSave = async () => {
  //   try {
  //     const web = new Web(testurl);

  //     // if (!newEntry.PaymentMode) {
  //     //   Swal.fire({
  //     //     icon: "warning",
  //     //     title: "Validation Error",
  //     //     text: "Please select a Payment Mode before saving.",
  //     //   });
  //     //   return;
  //     // }

  //     if (editMode) {
  //       //   // Update existing entry
  //       await web.lists
  //         .getById(testId)
  //         .items.getById(newEntry.Id)
  //         .update({
  //           dueDate: newEntry.dueDate,
  //           ReceivedDate: newEntry.ReceivedDate,
  //           ReceivedAmount: newEntry.ReceivedAmount,
  //           DueAmount: newEntry.DueAmount,
  //           PaymentMode: newEntry.PaymentMode,
  //           Status: newEntry.Status,
  //         });
  //       setFilteredData((prev) =>
  //         prev.map((item) =>
  //           item.Id === newEntry.Id ? { ...item, ...newEntry } : item
  //         )
  //       );
  //     } else {
  //       // Add new entry
  //       const response = await web.lists.getById(testId).items.add({
  //         dueDate: newEntry.dueDate,
  //         ReceivedDate: newEntry.ReceivedDate,
  //         ReceivedAmount: newEntry.ReceivedAmount,
  //         DueAmount: newEntry.DueAmount,
  //         PaymentMode: newEntry.PaymentMode,
  //         Status: newEntry.Status,
  //         StudentId: candidate.Id,
  //       });


  //       // Calculate Diff b/w ReceivedAmount and DueAmount
  //       const diff = newEntry.DueAmount - newEntry.ReceivedAmount;

  //       const addItem = response.data;

  //       const updatedEntry: Fee = {
  //         ...newEntry,
  //         Id: addItem.Id,
  //       };

  //       setFilteredData((prev) => {
  //         // Identify the next month`s entry based on dueDate
  //         const nextMonthDate = new Date(newEntry.dueDate);
  //         nextMonthDate.setMonth(nextMonthDate.getMonth() + 1);
  //         const nextMonthDateString = nextMonthDate.toISOString().split("T")[0];

  //         const updatedData = prev.map((item) => {
  //           // If the item's dueDate matches the next month's date, add the diff
  //           if (item.dueDate === nextMonthDateString) {
  //             return {
  //               ...item,
  //               DueAmount: item.DueAmount + diff,
  //             };
  //           }
  //           return item;
  //         });

  //         // Filter out entries with the same dueDate and Status as "unpaid"
  //         const filtered = updatedData.filter(
  //           (item) => item.dueDate !== updatedEntry.dueDate
  //         );

  //         // Add the updatedEntry to the filtered array
  //         return [...filtered, updatedEntry];
  //       });
  //     }
  //     // setFilteredData((prev) => [...prev, updatedEntry]);
  //     // }
  //     fetchAPIData();
  //     setIsPanelOpen(false);
  //     setNewEntry({
  //       Id: 0,
  //       dueDate: "",
  //       DueAmount: 0,
  //       ReceivedDate: "",
  //       ReceivedAmount: 0,
  //       PaymentMode: "",
  //       Student: candidate,
  //       Status: "unpaid",
  //     });
  //   } catch (error) {
  //     console.error("Error saving entry:", error);
  //   }

  //   await Swal.fire({
  //     title: "Fee  Details Saved",
  //     text: "Fee Saved",
  //     icon: "success",
  //     confirmButtonText: "OK",
  //   });
  // };

  const handleAdd = async () => {
    if (!newEntry.PaymentMode && !admin) {

      await Swal.fire({
        icon: "warning",
        title: "Validation Error",
        text: "Please select a Payment Mode before saving.",
        customClass: {
          container: "my-swal-container",
          popup: "my-swal-popup",
        }
      });
      return;
    }

    try {
      const web = new Web(testurl);
      const autoStatus = calculateStatus(newEntry.ReceivedAmount, newEntry.DueAmount);
      const response = await web.lists.getById(testId).items.add({
        dueDate: newEntry.dueDate,
        ReceivedDate: newEntry.ReceivedDate,
        ReceivedAmount: newEntry.ReceivedAmount,
        DueAmount: newEntry.DueAmount,
        PaymentMode: newEntry.PaymentMode,
        Status: autoStatus,
        StudentId: candidate.Id,
      });

      const addItem = response.data;

      const diff = newEntry.DueAmount - newEntry.ReceivedAmount;

      const updatedEntry: Fee = {
        ...newEntry,
        Id: addItem.Id,
      };

      setFilteredData((prev) => {
        const nextMonthDate = new Date(newEntry.dueDate);
        nextMonthDate.setMonth(nextMonthDate.getMonth() + 1);
        const nextMonthDateString = nextMonthDate.toISOString().split("T")[0];

        const updatedData = prev.map((item) => {
          if (item.dueDate === nextMonthDateString) {
            return {
              ...item,
              DueAmount: item.DueAmount + diff,
            };
          }
          return item;
        });

        const filtered = updatedData.filter(
          (item) => item.dueDate !== updatedEntry.dueDate
        );

        return [...filtered, updatedEntry];
      });

      fetchAPIData();
      setIsPanelOpen(false);
      await Swal.fire({
        title: "Fee Details Saved",
        text: "Entry added successfully",
        icon: "success",
        confirmButtonText: "OK",
      });


      resetForm();
    } catch (error) {
      console.error("Error adding entry:", error);
    }
  };

  const handleUpdate = async () => {
    if (!newEntry.PaymentMode && !admin) {
      await Swal.fire({
        icon: "warning",
        title: "Validation Error",
        text: "Please select a Payment Mode before saving.",
      });
      return;
    }

    try {
      const web = new Web(testurl);
      const autoStatus = calculateStatus(newEntry.ReceivedAmount, newEntry.DueAmount);
      await web.lists
        .getById(testId)
        .items.getById(newEntry.Id)
        .update({
          dueDate: newEntry.dueDate,
          ReceivedDate: newEntry.ReceivedDate,
          ReceivedAmount: newEntry.ReceivedAmount,
          DueAmount: newEntry.DueAmount,
          PaymentMode: newEntry.PaymentMode,
          Status: autoStatus,
        });

      setFilteredData((prev) =>
        prev.map((item) =>
          item.Id === newEntry.Id ? { ...item, ...newEntry } : item
        )
      );

      fetchAPIData();
      setIsPanelOpen(false);
      await Swal.fire({
        title: "Fee Details Updated",
        text: "Entry updated successfully",
        icon: "success",
        confirmButtonText: "OK",
      });


      resetForm();
    } catch (error) {
      console.error("Error updating entry:", error);
    }
  };

  const resetForm = () => {
    setNewEntry({
      Id: 0,
      dueDate: "",
      DueAmount: 0,
      ReceivedDate: "",
      ReceivedAmount: 0,
      PaymentMode: "",
      Student: candidate,
      Status: "unpaid",
    });
    setEditMode(false);
  };


  const handleSave = () => {
    if (editMode) {
      handleUpdate();
    } else {
      handleAdd();
    }
  };

  React.useEffect(() => {
    fetchAPIData();
    fetchAPIStudent();
  }, []);
  // console.log()
  console.log(admin);

  return (
    <div>
      <div className="clearfix col-12 mb-3">
        {
          <button
            className="btn button-color"
            onClick={() => handleOpenPanel()}
            style={{ float: "right" }}
          >
            Pay Dues
          </button>
        }
      </div>
      {dataFiltered.length > 0 ? (
        <div className="table-responsive table-bordered ">
          <table className="details-table">
            <thead className="thead-dark">
              <tr>
                <th>Student</th>
                <th> Due Date</th>
                <th>Due Amount</th>
                <th>Payment Date</th>
                <th>Paid Amount</th>
                <th>Payment Mode</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {dataFiltered.map((item) => (
                <tr key={item.Id}>
                  <td>{item.Student?.FullName || "N/A"}</td>
                  <td>
                    {item.dueDate
                      ? new Date(item.dueDate).toLocaleDateString("en-GB")
                      : ""}
                  </td>
                  <td>{item.DueAmount}</td>
                  <td>
                    {item.ReceivedDate
                      ? new Date(item.ReceivedDate).toLocaleDateString("en-GB")
                      : ""}
                  </td>
                  <td>{item.ReceivedAmount}</td>
                  <td>{item.PaymentMode}</td>
                  <td>
                    <button
                      className={`status-btn ${item.Status.toLowerCase() === "paid"
                        ? "status-paid"
                        : item.Status.toLowerCase() === "partial paid"
                          ? "status-partial-paid"
                          : "status-unpaid"
                        }`}
                      disabled={
                        item.Status.toLowerCase() === "paid"
                      }
                      onClick={() => handleOpenPanel(item)}
                    >
                      {item.Status}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <div className="no-table">
          <p className="notable-msg">No Data Available</p>
        </div>
      )}

      <Panel
        isOpen={isPanelOpen}
        onDismiss={() => setIsPanelOpen(false)}
        headerText={editMode ? "Edit Fee Details" : "Add Fee Details"}
        type={PanelType.medium}
        isFooterAtBottom={true}
        onRenderFooterContent={() => (
          <div>
            <PrimaryButton
              onClick={handleSave}
              styles={{ root: { marginRight: 8 } }}
              className="button-color"
            >
              {editMode ? "Update Entry" : "Add Entry"}
            </PrimaryButton>
            <DefaultButton onClick={() => setIsPanelOpen(false)}>
              Cancel
            </DefaultButton>
          </div>
        )}
      >
        {admin && (<TextField
          label=" Due Date"
          type="date"
          value={newEntry?.dueDate}
          onChange={(e) => handleInputChange(e, "dueDate")}
          readOnly={admin ? false : true}
        />)}
        {admin && (<TextField
          label="Due Amount"
          type="number"
          value={newEntry?.DueAmount?.toString()}
          onChange={(e) => handleInputChange(e, "DueAmount")}
          readOnly={admin ? false : true}
        />)}
        <TextField
          label="Payment Date"
          type="date"
          value={newEntry?.ReceivedDate}
          onChange={(e) => handleInputChange(e, "ReceivedDate")}
        />
        {/* <ChoiceGroup
          label="Payment Type"
          options={[
            { key: "due", text: "Due Amount" },
            { key: "other", text: "Other Amount" },
          ]}
          onChange={(e, option) => {
            if (option?.key === "due") {
              setNewEntry((prev) => ({
                ...prev,
                ReceivedAmount: prev.DueAmount,
              }));
            } else {
              setNewEntry((prev) => ({ ...prev, ReceivedAmount: 0 }));
            }
          }}
        /> */}

        <TextField
          label="Payment Amount"
          type="number"
          value={newEntry?.ReceivedAmount?.toString()}
          onChange={(e) => handleInputChange(e, "ReceivedAmount")}
        />

        <Dropdown
          label="Payment Mode"
          options={paymentOptions}
          selectedKey={newEntry?.PaymentMode}
          required={admin ? false : true}
          errorMessage={(!newEntry.PaymentMode && !admin) ? "Payment Mode is required." : ""}
          onChange={(e, option) =>
            setNewEntry((prev) => ({
              ...prev,
              PaymentMode: option?.key as string,
            }))
          }
        />
        {/* <Dropdown
          label="Status"
          options={statusOptions}
          selectedKey={newEntry?.Status}
          disabled={true} // didn't want to change status from here
          onChange={(e, option) =>
            setNewEntry((prev) => ({ ...prev, Status: option?.key as string }))
          }
        /> */}
        <TextField
          label="Status"
          value={newEntry.Status}
          readOnly
        />
      </Panel>
    </div>
  );
};

export default FeeDetails;


