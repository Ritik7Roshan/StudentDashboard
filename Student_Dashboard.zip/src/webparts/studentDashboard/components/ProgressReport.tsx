import * as React from "react";
import { Web } from "sp-pnp-js";
import "./StudentProfile.css";
import { Panel, PanelType } from "@fluentui/react/lib/Panel";
import {
  DefaultButton,
  PrimaryButton,
  TextField,
  Dropdown,
  IDropdownOption,
} from "@fluentui/react";
import Swal from "sweetalert2";

interface ProgressReport {
  Id: number;
  Total: number;
  SubjectEntries: {
    date: string;
    subject: string;
    obtained: number;
    full: number;
    percentage: number | null;
  }[];
}


interface ProgressReportProps {
  candidate: any;
  props: any;
  fetchStudentById: any;
  subjectReports: {
    date: string;
    subject: string;
    obtained: number;
    full: number;
    percentage: number | null;
  }[];
}

// type SubjectKey = "Physics" | "Chemistry" | "Maths" | "Biology";

const ProgressReport: React.FC<ProgressReportProps> = ({
  candidate,
  props,
  fetchStudentById,
  subjectReports,
}) => {
  const [progressReports, setProgressReports] = React.useState<
    ProgressReport[]
  >(
    candidate.ProgressReport
      ? JSON.parse(candidate.ProgressReport).sort(
        (a: ProgressReport, b: ProgressReport) =>
          new Date(a.SubjectEntries[0].date).getTime() - new Date(b.SubjectEntries[0].date).getTime()// Ascending Order (Oldest First)
        )
      : []
  );

  // Extract subjects opted dynamically
  const subjectsOpted =
    candidate?.SubjectsOpted?.map((item: any) => item?.Title) || [];

  // Initialize a new entry dynamically
  const initializeNewEntry = () => {
    const entry: any = {
      Id: progressReports.length + 1,
      Date: "",
      Total: 0,
      ...Object.fromEntries(
        subjectsOpted.flatMap((sub: any) => [
          [sub, 0],
          [`${sub}Full`, 0],
        ])
      ),
    };
    return entry;
  };

  const [isPanelOpen, setIsPanelOpen] = React.useState(false);
  const [newEntry, setNewEntry] = React.useState<ProgressReport>(
    initializeNewEntry()
  );

  const [subjectEntries, setSubjectEntries] = React.useState(
    subjectsOpted.map((subject: any) => ({ date: Date.now(), subject, obtained: 0, full: 0 }))
  );

  const testurl = props?.props?.context?.pageContext?.web?.absoluteUrl;
  const testId = props?.props?.StudentListId;

  // const subjectOptions: IDropdownOption[] = [
  //   { key: "Physics", text: "Physics" },
  //   { key: "Chemistry", text: "Chemistry" },
  //   { key: "Maths", text: "Maths" },
  //   { key: "Biology", text: "Biology" },
  // ];

  // Subject options dropdown
  const subjectOptions: IDropdownOption[] = subjectsOpted.map(
    (subject: any) => ({
      key: subject,
      text: subject,
    })
  );

  const handleOpenPanel = () => {
    setIsPanelOpen(true);
    setNewEntry(initializeNewEntry());
    setSubjectEntries([{ subject: subjectsOpted[0], obtained: 0, full: 0 }]); // Start with one empty entry
  };
  const handleClosePanel = () => setIsPanelOpen(false);

  // Handle subject selection and marks input dynamically
  const handleSubjectChange = (
    index: number,
    key: string,
    value: string | number
  ) => {
    setSubjectEntries((prev: any) =>
      prev.map((entry: any, i: any) =>
        i === index ? { ...entry, [key]: value } : entry
      )
    );
  };

  // Add a new subject entry
  const addSubjectEntry = () => {
    setSubjectEntries([
      ...subjectEntries,
      { date: Date.now(), subject: subjectsOpted[0], obtained: 0, full: 0 },
    ]);
  };

  // Remove a subject entry
  const removeSubjectEntry = (index: number) => {
    setSubjectEntries(subjectEntries.filter((_: any, i: any) => i !== index));
  };

  // Save progress report
  const addFunction = async () => {
    const updatedEntry = { ...newEntry };

    let obtainedMarks = 0;
    let totalFullMarks = 0;

    subjectEntries.forEach(({ obtained, full }: any) => {
      obtainedMarks += obtained;
      totalFullMarks += full;
    });
    console.log(totalFullMarks );
    updatedEntry.Total = obtainedMarks;
    updatedEntry.SubjectEntries = subjectEntries;

    const updatedProgressReports = [...progressReports, updatedEntry];
    updatedProgressReports.sort(
      (a, b) => new Date(a.SubjectEntries[0]?.date || "").getTime() - new Date(b.SubjectEntries[0]?.date || "").getTime()
    );
    setProgressReports(updatedProgressReports);

    try {
      const web = new Web(testurl);
      await web.lists
        .getById(testId)
        .items.getById(candidate.Id)
        .update({
          ProgressReport: JSON.stringify(updatedProgressReports),
        });
    } catch (error) {
      console.error("Error updating progress report:", error);
    }

    setIsPanelOpen(false);
    setNewEntry(initializeNewEntry());
    setSubjectEntries([{ date: "", subject: subjectsOpted[0], obtained: 0, full: 0 }]);

    await Swal.fire({
      title: "Report Saved",
      text: "Marks entered have been saved!",
      icon: "success",
      confirmButtonText: "OK",
    });

    fetchStudentById(candidate.Id);
  };

  const calculateStatus = (
    total: number,
    fullMarks: number
  ): { text: string; color: string } => {
    const percentage = (total / fullMarks) * 100;
    return percentage >= 33
      ? { text: "Pass", color: "green" }
      : { text: "Fail", color: "red" };
  };

  return (
    <div>
      {/* <span className="text-right mb-3 clearfix">
        <button
          className="btn button-color pull-right"
          onClick={handleOpenPanel}
        >
          Add New Scores
        </button>
      </span> */}

{progressReports.length > 0 ? (
  <>
        <div className="table-progress p-2">
          <div className="table-responsive table-bordered ">
          <table className="details-table m-0">
            <thead className="thead-dark">
              <tr>
                <th>Date</th>
                {/* {subjectsOpted.map((subject: any) => (
                  <th key={subject}>{subject}</th>
                ))} */}
                <th>Subjects</th>
                <th>Marks</th>
                <th>Total</th>
                <th>Percentage</th>
                <th>Status</th>
              </tr>
            </thead>
            {/* <tbody>
              {progressReports.map((report) => {
                const totalFullMarks = subjectsOpted.reduce(
                  (sum: any, sub: any) =>
                    sum + ((report as any)[`${sub}Full`] || 0),
                  0
                );
                const status = calculateStatus(report.Total, totalFullMarks);
                return (
                  <tr key={report.Id}>
                    <td>
                      {report.Date
                        ? new Date(report.Date).toLocaleDateString("en-GB")
                        : ""}
                    </td>
                    {subjectsOpted.map((subject: any) => (<>
                      <td key={subject}>{subject.date? new Date(subject.date).toLocaleDateString("en-GB")
                        : ""}</td>
                      <td key={subject}>{(report as any)[subject] || 0}</td>
                      </>
                    ))}
                    <td>
                      {report.Total}/{totalFullMarks}
                    </td>
                    <td style={{ color: status.color }}>{status.text}</td>
                  </tr>
                );
              })}
            </tbody> */}

            <tbody>
              {/* {progressReports.flatMap((report) =>
                report.SubjectEntries.filter((entry)=>{ return entry.subject===selectedSubject}).map((entry, index) => {
                  const status = calculateStatus(entry.obtained, entry.full);
                  return (
                    <tr key={`${report.Id}-${index}`}>
                      <td>
                        {entry.date
                          ? new Date(entry.date).toLocaleDateString("en-GB")
                          : ""}
                      </td>
                      <td>{entry.subject}</td>
                      <td>{entry.obtained}</td>
                      <td>{entry.full}</td>
                      <td>
                        {entry.full > 0
                          ? `${((entry.obtained / entry.full) * 100).toFixed(2)}%`
                          : "N/A"}
                      </td>
                      <td style={{ color: status.color }}>{status.text}</td>
                    </tr>
                  );
                })
              )} */}
               {subjectReports.map((entry, idx) => {
            const status = calculateStatus(entry.obtained, entry.full);
            return (
              <tr key={`${entry.date}-${idx}`}>
                <td>{new Date(entry.date).toLocaleDateString("en-GB")}</td>
                <td>{entry.subject}</td>
                <td>{entry.obtained}</td>
                <td>{entry.full}</td>
                <td>{entry.percentage != null ? `${entry.percentage.toFixed(2)}%` : "N/A"}</td>
                <td style={{ color: status.color }}>{status.text}</td>
              </tr>
            );
          })}
            </tbody>


          </table>
          </div>
          <div className="text-right mb-3 clearfix p-2">
        <button
          className="btn button-color pull-right"
          onClick={handleOpenPanel}
        >
          Add New Scores
        </button>
      </div>
        </div>
        
      </>
      ) : (
        <div className="no-Prtable ">
          <h4 className="msg">No Test Enteries for the Student </h4>
          <span className="text-right mb-3 clearfix">
            <button
              className="btn button-color pull-right"
              onClick={handleOpenPanel}
            >
              Add New Scores
            </button>
          </span>
        </div>
      )}

      <Panel
        isOpen={isPanelOpen}
        onDismiss={handleClosePanel}
        headerText="Add New Progress Report"
        type={PanelType.medium}
        closeButtonAriaLabel="Close"
        onRenderFooterContent={() => (
          <div>
            <PrimaryButton
              onClick={addFunction}
              styles={{ root: { marginRight: 8 } }}
              className="button-color"
            >
              Add Entry
            </PrimaryButton>
            <DefaultButton onClick={handleClosePanel}>Cancel</DefaultButton>
          </div>
        )}
        isFooterAtBottom={true}
      >
        <div>
           

        {subjectEntries.map((entry: any, index: any) => (
            <div key={index} className="subject-entry">
              <div className="row">
                <TextField
                  label="Date"
                  type="date"
                  value={entry.date}
                  className="col-3"
                  onChange={(e) => {
                    // setNewEntry((prev) => ({
                    //   ...prev,
                    //   Date: (e.target as HTMLInputElement).value,
                    // }));
                    setSubjectEntries((prev: any) => {
                      const updatedEntries = [...prev];
                      updatedEntries[index].date = (e.target as HTMLInputElement).value;
                      return updatedEntries;
                    });
                  }}
                />
                <div className="col-3">
                  <Dropdown
                    label="Select Subject"
                    options={subjectOptions}
                    selectedKey={entry.subject}
                    onChange={(e, option) =>
                      handleSubjectChange(
                        index,
                        "subject",
                        option?.key as string
                      )
                    }
                  />
                </div>
                <div className="col-3">
                  <TextField
                    label="Marks Obtained"
                    type="number"
                    value={entry.obtained.toString()}
                    onChange={(e) =>
                      handleSubjectChange(
                        index,
                        "obtained",
                        parseFloat((e.target as HTMLInputElement).value)
                      )
                    }
                  />
                </div>
                <div className="col-3">
                  <TextField
                    label="Full Marks"
                    type="number"
                    value={entry.full.toString()}
                    onChange={(e) =>
                      handleSubjectChange(
                        index,
                        "full",
                        parseFloat((e.target as HTMLInputElement).value)
                      )
                    }
                  />
                </div>
                <div className="col-3">
                  <label className="remove-btn-progressReport"> </label>
                  {subjectEntries.length > 1 && (
                    <DefaultButton
                      text="Remove"
                      className="removeBtn"
                      onClick={() => removeSubjectEntry(index)}
                    />
                  )}
                </div>
              </div>
            </div>
          ))}

          <PrimaryButton
            text="Add Subject Entry"
            onClick={addSubjectEntry}
            className="button-color subjEntry"
          />
        </div>
      </Panel>
    </div>
  );
};

export default ProgressReport;
